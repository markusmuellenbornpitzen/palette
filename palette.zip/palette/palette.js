$( document ).ready(function() {



  $( ".filter" ).click(function() {
     var tofilter=$( this ).attr("data-tosort");

     if(tofilter=="all"){
       $( ".palette-frame" ).each(function() {


           ($( this ).slideDown( 300 )).delay( 800 ).fadeIn(300);
           var cards = $(".palette-frame");
            for(var i = 0; i < cards.length; i++){
              var target = Math.floor(Math.random() * cards.length -1) + 1;
              var target2 = Math.floor(Math.random() * cards.length -1) +1;
              cards.eq(target).before(cards.eq(target2));
           }




       });
     }

     else{

     $( ".palette-frame" ).each(function() {

       if(($( this ).attr("data-sort"))==tofilter){
         //($( this ).css("display","block"));
         ($( this ).slideUp( 300 )).delay( 800 ).fadeOut(300);
         ($( this ).slideDown( 300 )).delay( 800 ).fadeIn(300);
         var cards = $(".palette-frame");
          for(var i = 0; i < cards.length; i++){
            var target = Math.floor(Math.random() * cards.length -1) + 1;
            var target2 = Math.floor(Math.random() * cards.length -1) +1;
            cards.eq(target).before(cards.eq(target2));
         }

       }
       else{

         ($( this ).slideUp( 300 )).delay( 800 ).fadeOut(300);
       }

       var cards = $(".palette-frame");
        for(var i = 0; i < cards.length; i++){
          var target = Math.floor(Math.random() * cards.length -1) + 1;
          var target2 = Math.floor(Math.random() * cards.length -1) +1;
          cards.eq(target).before(cards.eq(target2));
       }

     });

   }



  });


});//End of Document Ready Function
